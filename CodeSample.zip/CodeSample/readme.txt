
First run the PowerShell script. Replace these lines wth your info:

$appName = "someAppName" -->This can be anything but must not be the name of an existing object in your directory.
$Uri = "http://someAppName" -->This can be anything as well.
$password = "123appDb!" --> Give it a password.

Note where I mention to retry. You can pause there until the service principal is completely created - or retry until successful.

Copy the applicationId and password and add them to the VS project. It's this info that ties together your app and the AAD.

Now open the VS project and update the placeholder variables - all the auth and pool variables. 


Run it and it should work!