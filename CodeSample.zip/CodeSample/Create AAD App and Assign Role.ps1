﻿
# logon with your Azure credentials
Add-AzureRmAccount

# the Azure subscription id you want to work with
Set-AzureRmContext -SubscriptionId "<your sub id>"


# you provide these for your AAD app
$appName = "someAppName"
$Uri = "http://someAppName"
$password = "123appDb!"

# Create a new AAD app
$azureAdApplication = New-AzureRmADApplication -DisplayName $appName -HomePage $Uri -IdentifierUris $Uri -Password $password

# Create a new Service Principal for the app
New-AzureRmADServicePrincipal -ApplicationId $azureAdApplication.ApplicationId

#-----------------------------------
# Retry if you get an error here. I've seen several seconds before the service principal shows up in the directory.
#-----------------------------------
New-AzureRmRoleAssignment -RoleDefinitionName Reader -ServicePrincipalName $azureAdApplication.ApplicationId.Guid # We set to a Reader role (see RBAC articles for more info).

# Output the values we need for our auth code
Write-Output "Assign this value to the 'applicationId' variable in the example code: " $azureAdApplication.ApplicationId.Guid
Write-Output "Assign this value to the 'key' variable in the example code: " $password








