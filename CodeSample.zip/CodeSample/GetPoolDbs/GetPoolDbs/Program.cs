﻿using Microsoft.Azure;
using Microsoft.Azure.Management.Sql;
using Microsoft.Azure.Management.Sql.Models;
using Microsoft.IdentityModel.Clients.ActiveDirectory;
using System;

namespace GetPoolDbs
{
    class Program
    {
        // your Azure subscription ID
        static string subscriptionId = "<xxxxxxx-xxxx-xxxx-xxxx-xxxxxxxxxxxx>";

        // auth related variables
        static string applicationId = "<xxxxxxx-xxxx-xxxx-xxxx-xxxxxxxxxxxx>";
        static string key = "<pa$$word>";
        static string aadDomain = "<microsoft.onmicrosoft.com>";

        // token variables
        static AuthenticationResult token;
        static TokenCloudCredentials tccreds;


        static void Main(string[] args)
        {

            Console.WriteLine("Getting access token...");
            token = GetAccessToken();
            tccreds = new TokenCloudCredentials(subscriptionId, token.AccessToken);
            Console.WriteLine("Token expires on: " + token.ExpiresOn.ToString());

            ListDatabasesInAPool();

            Console.WriteLine("Press enter to exit...");
            Console.ReadLine();
        }


        static void ListDatabasesInAPool()
        {

            // specific to your existing pool
            string resourceGroup = "<rgname>";
            string server = "<servername>";
            string elasticPool = "<elasticpoolname>";


            SqlManagementClient sqlClient = new SqlManagementClient(new TokenCloudCredentials(subscriptionId, token.AccessToken));

            // Get all databases in a pool
            DatabaseListResponse dbsInPool = sqlClient.ElasticPools.ListDatabases(resourceGroup, server, elasticPool);

            Console.WriteLine("Elastic Pool: {0}.{1} contains {2} databases:", elasticPool, server, dbsInPool.Databases.Count.ToString());
            foreach (Database db in dbsInPool)
            {
                Console.WriteLine("  Database: {0}", db.Name);
            }
        }

        private static AuthenticationResult GetAccessToken()
        {
            AuthenticationContext authContext = new AuthenticationContext
                ("https://login.windows.net/" /* AAD URI */
                + aadDomain /* Tenant ID or AAD domain */);

            ClientCredential cc = new ClientCredential(applicationId, key);

            AuthenticationResult token = authContext.AcquireToken(
                "https://management.azure.com/"/* the Azure Resource Management endpoint */,
                cc);

            return token;
        }
    }
}
